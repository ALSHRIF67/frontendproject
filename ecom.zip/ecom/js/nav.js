const createNav =() =>{
    let nav =document.querySelector('.navbar');
    nav.innerHTML='';

}
createNav();